/*******************************************************************************
 * Copyright (c) 2020, The GremsyCo
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification,
 * are strictly prohibited without prior permission of The GremsyCo.
 *
 * @file    gremsy_flir_camera.c
 * @author  The GremsyCo
 * @version V1.0.0
 * @date    Aug-27-2020
 * @brief   This file contains lower function for interfacing with FLIR camera
 *
 * -----------------------------------------------------------------------------
 * MSX (Multi Spectral Dynamic Imaging). It provides extraordinary in real-time thermal images
 * by embossing visible camera image information on thermal video and stills.
 * MSX produes exceptional thermal clarity and ensures easier taget indentification without compromising
 * radiometric data. 
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 ******************************************************************************/
/* Private includes ----------------------------------------------------------*/
/*!< DJI library */
#include "uart.h"
#include "eeprom.h"
#include "utils/util_misc.h"
/*!< Flir includes file*/
#include "flir_cam/gsdk_flir_camera.h"
/*!< Include mavlink library */
#include "lib/mavlink/gsdk_mavlink.h"
/*!< Include the structure and function prototype*/
#include "osal/osal.h"
/*!< Include Som*/
#include "som/gsdk_som.h"

/*!< Include logger for debugging */
#include "psdk_logger.h"

/*!< Get data for geotagging */
#include "data_subscription/test_data_subscription.h"

/* Private constants ---------------------------------------------------------*/
/*!< Supported PixyF*/
#define GIMBAL_PIXYF
#define SLOG_CAMERA     STD_ON

#if SLOG_CAMERA
# define DebugMsg(fmt, args ...) do {PsdkLogger_UserLogMsg("[%s]:[%d]: " fmt "\n", __FUNCTION__, __LINE__, ## args); } while(0);
# define DebugInfo(fmt, args ...) do {PsdkLogger_UserLogInfo("[%s]:[%d]: " fmt "\n", __FUNCTION__, __LINE__, ## args); } while(0);
# define DebugWarning(fmt, args ...) do {PsdkLogger_UserLogWarn("[%s]:[%d]: " fmt "\n", __FUNCTION__, __LINE__, ## args); } while(0);
# define DebugError(fmt, args ...) do {PsdkLogger_UserLogError("[%s]:[%d]: " fmt "\n", __FUNCTION__, __LINE__, ## args); } while(0);
#else
# define DebugMsg(fmt, args ...)
# define DebugInfo(fmt, args ...)
# define DebugWarning(fmt, args ...)
# define DebugError(fmt, args ...)
#endif

/* Private define ------------------------------------------------------------*/
#ifdef GIMBAL_PIXYU
/*!< Define Hardware Interface PIXY U*/
#define FLIR_CAMERA_TASK_FREQ                   (1000)
#define FLIR_CAMERA_TASK_STACK_SIZE             (1024)


#define PSDK_COMM_WITH_CAMERA_UART_NUM          UART_NUM_4
#define PSDK_COMM_WITH_CAMERA_UART_BAUD         57600
#define PSDK_COMM_WITH_CAMERA_BUFFER_SIZE       (255)
#else
/*!< Define Hardware Interface PIXY F*/
#define FLIR_CAMERA_TASK_FREQ                   (1000)
#define FLIR_CAMERA_TASK_STACK_SIZE             (2048) /*!< BUG: = 1024 FAILED stack size*/

#define PSDK_COMM_WITH_CAMERA_UART_NUM          UART_NUM_5
#define PSDK_COMM_WITH_CAMERA_UART_BAUD         57600
#define PSDK_COMM_WITH_CAMERA_BUFFER_SIZE       (255)
#endif

#define PSDK_COMM_WITH_CAMERA_MAV_CHAN          MAVLINK_COMM_1
/* Define ID interface with the camera */
#define PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID      1

#define PSDK_COMM_WAIT_RESPOND_TIMEOUT          6000 /*!< Unit: ms*/
#define PSDK_COMM_WAIT_ACK_TIMEOUT              1000 /*!< Unit: ms*/
/* Private typedef -----------------------------------------------------------*/

#define PARAM_RETRY_PERIOD                      100     /*!< Unit: ms*/
#define PARAM_MAX_FETCH_ATTEMPTS                5       /*!< Max times to fetch*/

/**
 * @brief Param state 
 * @details This enum value used for param state 
 * @note 
 */
typedef enum 
{
    PARAM_STATE_NOT_YET_READ = 0,   /*!< Parameter has yet to be initialized*/
    PARAM_STATE_FETCH_AGAIN = 1,    /*!< Parameter is being fetched */
    PARAM_STATE_ATTEMPTING_TO_SET = 2, /*!< Parameter is being set */
    PARAM_STATE_CONSISTENT = 3,     /*!< Parameter is consistent */
    PARAM_STATE_NONEEXISTANT = 4,   /*!< Param does not seem to exist*/
} E_ParamState;

/*!< Flashing step */
typedef enum {
    PARAM_NOT_FLASHING = 0,
    PARAM_FLASHING_WAITING_FOR_SET,
    PARAM_FLASHING_WAITING_FOR_ACK
}E_ParamFlashingStep;

/*!< PARAM_ID. Defined following the Application Usage  */
typedef enum _E_ParamCamIdx {
    PARAM_ID_VERSION_X = 0,
    PARAM_ID_VERSION_Y,
    PARAM_ID_VERSION_Z,
    PARAM_ID_CAM_ID,
    PARAM_ID_VIDEO_TRANSMISSION,
    PARAM_ID_TRANSMISSION_MODE,
    PARAM_ID_TYPE_RECORDING,
    PARAM_ID_SENCE_MODE,
    PARAM_ID_COLOR_PALETTE,
    PARAM_ID_APERTURE,
    PARAM_ID_ISO_NUM,
    PARAM_ID_ROTATION_IMAGE,
    PARAM_ID_MSX_ENABLE,
    PARAM_ID_MSX_LENGTH,
    PARAM_ID_FILE_FORMAT,
    PARAM_ID_VIDEO_FILE_TYPE,
    PARAM_ID_TEMP_UNIT,
    PARAM_ID_TEMP_METER,
    PARAM_ID_SUBJECT_EMISSIVITY,
    PARAM_ID_SKY_CONDITION,
    PARAM_ID_AIR_TEMPERATURE,
    PARAM_ID_HUMIDITY,
    PARAM_ID_SUBJECT_RANGE,

    PARAM_ID_NUM_TRACKED,
} E_CamParamIdx;

/**
 * @brief Storage used to save value 
 */
typedef enum {
    GSDK_STORAGE_STATE_IDLE,
    
    GSDK_STORAGE_STATE_INIT,
    GSDK_STORAGE_STATE_SAVE,
    GSDK_STORAGE_STATE_WAIT,
    GSDK_STORAGE_STATE_CHECK,
    
    GSDK_STORAGE_STATE_DONE,
    GSDK_STORAGE_STATE_ERROR,
} E_PsdkStorageState;


/*!< Define param list for camera. Default*/
struct {
    const uint8_t       camIdx;            /*< Camera parameter index */
    const char*         camId;             /*< Camera parameter identify */
    int16_t             value;              /*< Camera parameter value */

    E_ParamState        state;              /*< State's parameters */
    uint8_t             fetchAttempts;     /*< Retry to fetch parameter*/
    bool                seen;
} s_camParams[] = {
    {PARAM_ID_VERSION_X,            "VERSION_X",            1,                              PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_VERSION_Y,            "VERSION_Y",            0,                              PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_VERSION_Z,            "VERSION_Z",            0,                              PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_CAM_ID,               "CAM_ID",               100,                            PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_VIDEO_TRANSMISSION,   "VIDEO_TRANSMISSION",   FLIR_VIDEO_TRANSMISSION_VIS,    PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_TRANSMISSION_MODE,    "TRANSMISSION_MODE",    0,                              PARAM_STATE_NONEEXISTANT, 0, false},
    {PARAM_ID_TYPE_RECORDING,       "TYPE_RECORDING",       FLIR_FILE_FORMART_FFF,          PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_SENCE_MODE,           "SENCE_MODE",           FLIR_SCENE_OUTDOOR,             PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_COLOR_PALETTE,        "COLOR_PALETTE",        FLIR_PATETTE_LAVA,              PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_APERTURE,             "APERTURE",             0,                              PARAM_STATE_NONEEXISTANT, 0, false},
    {PARAM_ID_ISO_NUM,              "ISO_NUM",              0,                              PARAM_STATE_NONEEXISTANT, 0, false},
    {PARAM_ID_ROTATION_IMAGE,       "ROTATION_IMAGE",       FLIR_ROTARY_0,                  PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_MSX_ENABLE,           "MSX_ENABLE",           0,                              PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_MSX_LENGTH,           "MSX_LENGTH",           50,                             PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_FILE_FORMAT,          "FILE_FORMAT",          FLIR_FILE_FORMART_JPEG_TIFF,    PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_VIDEO_FILE_TYPE,      "VIDEO_FILE_TYPE",      FLIR_VIDEO_FILE_TYPE_H264,      PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_TEMP_UNIT,            "TEMP_UNIT",            FLIR_TEMP_UNIT_C,               PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_TEMP_METER,           "TEMP_METER",           FLIR_SPOT_METER_OFF,            PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_SUBJECT_EMISSIVITY,   "SUBJECT_EMISSIVITY",   50,                             PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_SKY_CONDITION,        "SKY_CONDITION",        FLIR_CLEAR_SKIES,               PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_AIR_TEMPERATURE,      "AIR_TEMPERATURE",      32,                             PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_HUMIDITY,             "HUMIDITY",             HUMIDITY_MEDIUM_45,             PARAM_STATE_NOT_YET_READ, 0, false},
    {PARAM_ID_SUBJECT_RANGE,        "SUBJECT_RANGE",        200,                            PARAM_STATE_NOT_YET_READ, 0, false},
};

typedef struct {
    int32_t VERSION_X;
    int32_t VERSION_Y;
    int32_t VERSION_Z;
    int32_t CAM_ID;
    int32_t VIDEO_TRANSMISSION;
    int32_t TRANSMISSION_MODE;
    int32_t TYPE_RECORDING;
    int32_t SENCE_MODE;
    int32_t COLOR_PALETTE;
    int32_t APERTURE;
    int32_t ISO_NUM;
    int32_t ROTATION_IMAGE;
    int32_t MSX_ENABLE;
    int32_t MSX_LENGTH;
    int32_t FILE_FORMAT;
    int32_t VIDEO_FILE_TYPE;
    int32_t TEMP_UNIT;
    int32_t TEMP_METER;
    int32_t SUBJECT_EMISSIVITY;
    int32_t SKY_CONDITION;
    int32_t AIR_TEMPERATURE;
    int32_t HUMIDITY;
    int32_t SUBJECT_RANGE;
} T_FlirParamters;


typedef enum {
    FLIR_PROCESS_PARAM_STATE_IDLE = 0,
    FLIR_PROCESS_PARAM_STATE_INITIALIZING,
    FLIR_PROCESS_PARAM_STATE_GET_SETTINGS,
    FLIR_PROCESS_PARAM_STATE_PROCESS,
    
    FLIR_PROCESS_PARAM_STATE_ERROR,
    
} E_FlirProcessParamState;

E_FlirProcessParamState s_paramProcessState = FLIR_PROCESS_PARAM_STATE_IDLE;

/**
 * @brief Structure contain all information related to FLIR camera 
 * @details This structure type is used to
 * @note 
 */
typedef struct _T_FLIRHandle
{
    uint32_t            lastTimeConnection;
    bool                isCameraConnected;
    bool                isSOMReseted;
    
    mavlink_message_t   msg;
    mavlink_status_t    status;
    /*!< Taget system and commponet ID*/
    uint8_t             targetSystem;
    uint8_t             targetComponent;
    
    /*!< Define the handler for mavlink camera */
    gremsy_mavlink_handler_t mavHandler;
    
    /*!< Ping Sequence */
    uint32_t                pingSeq;
    
    /*!< Type Request Data Stream */
    uint32_t                isReqDataStream;
    uint16_t                msgRate;
    
    /*!< ACK*/
    uint16_t                waitCommandAck;
    T_PsdkMutexHandle       mutexSendGetAck;
    T_PsdkSemHandle         semaphoreWaitAck;
    
} T_FLIRHandle;

/*!< Process state for camera */
typedef enum {
    CAMERA_RUNNING_STATE_IDLE = 0,
    
    CAMERA_RUNNING_STATE_CHECK_CONNECTION,
    
    CAMERA_RUNNING_STATE_DEFAULT_SETTING,
    
    CAMERA_RUNNING_QUERY_CAMERA_SETTING,
    
    CAMERA_RUNNING_STATE_PROCESS_EVENT,
    
    CAMERA_RUNNING_STATE_ERROR,
} E_CameraRunningState;

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/*!< Structure contain FLIR handler */
static T_FLIRHandle *s_pFLIRHandle = NULL;

/*!< Global FLIR CAMERA */
static T_FLIRCamera s_FLIRCamera;
T_FLIRCamera * const FLIRCamera = &s_FLIRCamera;


/*!< OS Vairables */
/*!<   buffer used to receive data from UART interface */
static uint8_t                      s_uartRecBuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE];

/*!< Task handler ID for processing wiris protocol*/
static T_PsdkTaskHandle             s_recvThread;

/*!< Task handler ID for processing user application*/
static T_PsdkTaskHandle             s_processCmdThread;

/*!< Event update for callback request*/
static EventGroupHandle_t           s_eventCamera;

/*!< Camera running status */
E_CameraRunningState                s_cameraRunningState = CAMERA_RUNNING_STATE_IDLE;

static uint32_t                     s_lastRequestMs = 0;
static uint32_t                     s_lastSetMs = 0;
static E_ParamFlashingStep          s_flashingStep;

/* Private function prototypes -----------------------------------------------*/
/**
  * @brief Struct brief comment.
  */

typedef struct
{
    /** @brief      ham doc ten cua param duoc dat theo string
        @param[in] index vi tri nam trong mang param
        @retuen     name string
    */
    T_PsdkReturnCode (*PsdkStorage_Initialized)(void);
    
    /** @brief      ham doc ten cua param duoc dat theo string
        @param[in] index vi tri nam trong mang param
        @retuen     name string
    */
    T_PsdkReturnCode (*PsdkStorage_ReceviedAll)(void);
    
    /** @brief      ham doc ten cua param duoc dat theo string
        @param[in] index vi tri nam trong mang param
        @retuen     name string
    */
    T_PsdkReturnCode (*PsdkStorage_Update)(void);
    
    /** @brief      ham doc ten cua param duoc dat theo string
        @param[in] index vi tri nam trong mang param
        @retuen     name string
    */
    const char* (*PsdkStorage_GetID)(uint16_t index);
    
    /** @brief ham save va kiem tra param da duoc ghi vao flash hay chua
        @param[in]  add dia chi cua bien nam trong @see gremsy_storage_param_name_t
        @param[in]  value gia tri ghi vao flash
        @param[in]  count so phan tu can luu
        @return none
    */
    T_PsdkReturnCode (*PsdkStorage_SetParam)(uint16_t param, const int16_t value);
    /** @brief      ham doc gia tri cua param
        @param[in]  index vi tri nam trong mang param
        @retuen     param value
    */
    T_PsdkReturnCode (*PsdkStorage_GetParam)(uint16_t param, int16_t *value);
    
    /** @brief ham doc dia chi cua mang luu chuoi ky tu cua param
        @param none
        @return dia chi cua mang luu chuoi ky tu
    */
    const char* (*PsdkStorage_GetPointerID)(void);
    
    /** @brief ham doc dia chi cua mang luu gia tri 
        @param none
        @return dia chi cua mang luu gia tri
    */
    T_PsdkReturnCode (*PsdkStorage_GetPointerValue)(int16_t *value);
    
} T_PsdkStorageHandler;




/**
 * @brief Function initialize FLIR camera protocol 
 * @details This structure type is used to
 * @note 
 */
static T_PsdkReturnCode FLIRProto_CameraInit(void);

/**
  * @brief Function is used to initialize the wiris protocol
  * @retval T_PsdkReturnCode
  */
static T_PsdkReturnCode FlirCameraProto_DeInit(void);

/**
  * @brief Function is used to register the function send 
  * @retval T_PsdkReturnCode
  */
static T_PsdkReturnCode FlirCameraProto_RegSendDataFunc(SendCallbackFunc callbackFunc);

/**
  * @brief Function is used to register the function send 
  * @retval T_PsdkReturnCode
  */
static T_PsdkReturnCode FlirCameraProto_RegRecvDataFunc(ReceiveCallbackFunc callbackFunc);

/**
  * @brief Function is used to register the function send 
  * @retval T_PsdkReturnCode
  */
static T_PsdkReturnCode FlirProt_ProcessReceiveData(const uint8_t *pData, uint16_t realLen);

/* Exported variables --------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
T_PsdkReturnCode PsdkStorage_Init(T_PsdkStorageHandler *handler);

/** 
  * @brief Function used to convert platform for writing function 
  * @param none
  * @param none
  * @return None
  */
T_PsdkReturnCode PsdkFlir_Write(const uint16_t param, const int16_t value)
{
    
    uint16_t Status = EE_WriteVariable(param, value);

    /*!< Depending on mavlink or directly flash memory */
    if(Status != HAL_OK) {
        PsdkLogger_UserLogError("Write Failed [%d] param %d - %d", Status, param, value);
        
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** 
  * @brief Function used to convert platform for writing function 
  * @param none
  * @param none
  * @return None
  */
T_PsdkReturnCode PsdkFlir_Read(uint16_t param, int16_t *value)
{
    /*!< Depending on mavlink or directly flash memory */
    if(EE_ReadVariable(param, (uint16_t*)value) != HAL_OK) {
        
        PsdkLogger_UserLogInfo("Read Failed param %d - %d", param, value);
        
        return PSDK_ERROR_SYSTEM_MODULE_RAW_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}


/**
 * @brief Function used for reseting param 
 * @details
 * @note 
 */
T_PsdkReturnCode PsdkFlir_ResetParams(void)
{
    PsdkOsal_GetTimeMs(&s_lastRequestMs);
    PsdkOsal_GetTimeMs(&s_lastSetMs);

     /* Scan the array parameters */
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++)
    {
        s_camParams[i].value           = 0;
        s_camParams[i].state           = PARAM_STATE_NOT_YET_READ;
        s_camParams[i].fetchAttempts   = 0;
        s_camParams[i].seen            = false;
    }
    
    s_flashingStep = PARAM_NOT_FLASHING;
    
    DebugWarning("Completed");
}

/** 
  * @brief Function get param name based on the Index 
  * @param param - param index need to get the name
  * @return Name Id of that parameter
  */
const char *PsdkFlir_GetParamName(const uint16_t param)
{
    switch(param) {
        case PARAM_ID_VERSION_X: return "VERSION_X";
        case PARAM_ID_VERSION_Y: return "VERSION_Y";
        case PARAM_ID_VERSION_Z: return "VERSION_Z";
        case PARAM_ID_CAM_ID: return "CAM_ID";
        case PARAM_ID_VIDEO_TRANSMISSION: return "VIDEO_TRANSMISSION";
        case PARAM_ID_TRANSMISSION_MODE: return "TRANSMISSION_MODE";
        case PARAM_ID_TYPE_RECORDING: return "TYPE_RECORDING";
        case PARAM_ID_SENCE_MODE: return "SENCE_MODE";
        case PARAM_ID_COLOR_PALETTE: return "COLOR_PALETTE";
        case PARAM_ID_APERTURE: return "APERTURE";
        case PARAM_ID_ISO_NUM: return "ISO_NUM";
        case PARAM_ID_ROTATION_IMAGE: return "ROTATION_IMAGE";
        case PARAM_ID_MSX_ENABLE: return "MSX_ENABLE";
        case PARAM_ID_MSX_LENGTH: return "MSX_LENGTH";
        case PARAM_ID_FILE_FORMAT: return "FILE_FORMAT";
        case PARAM_ID_VIDEO_FILE_TYPE: return "VIDEO_FILE_TYPE";
        case PARAM_ID_TEMP_UNIT: return "TEMP_UNIT";
        case PARAM_ID_TEMP_METER: return "TEMP_METER";
        case PARAM_ID_SUBJECT_EMISSIVITY: return "SUBJECT_EMISSIVITY";
        case PARAM_ID_SKY_CONDITION: return "SKY_CONDITION";
        case PARAM_ID_AIR_TEMPERATURE: return "AIR_TEMPERATURE";
        case PARAM_ID_HUMIDITY: return "HUMIDITY";
        case PARAM_ID_SUBJECT_RANGE: return "SUBJECT_RANGE";
        default: return "";
    }
}

/** 
  * @brief Function Fetch Paramerters
  * @param none
  * @return Execution Result
  */
T_PsdkReturnCode PsdkFlir_FetchParams(void)
{
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++){
        /*!< Check whether param has been read before then set state to fetch again */
        if(s_camParams[i].state != PARAM_STATE_NOT_YET_READ) {
            s_camParams[i].state = PARAM_STATE_FETCH_AGAIN;
        }
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** 
  * @brief Function used for checking whether parameters has been initialized 
  * @param none
  * @return True - Parameters have been read
  *         False - Parameters haven't read all
  */
T_PsdkReturnCode PsdkFlir_InitializedParams(void)
{
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++){
        /*!< Check whether param has been read before then set state to fetch again */
        if(s_camParams[i].state == PARAM_STATE_NOT_YET_READ) {
            return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
        }
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** 
  * @brief Function used for checking whether parameters has been recevied 
  * @param none
  * @return Return parameter index or if read all return param num tracked 
  */
T_PsdkReturnCode PsdkFlir_ReceivedAllParams(void)
{
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++){
        /*!< Check whether param has been read before then set state to fetch again */
        if(s_camParams[i].state == PARAM_STATE_NOT_YET_READ || s_camParams[i].state == PARAM_STATE_FETCH_AGAIN) {
            return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
        }
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** 
  * @brief Function used for getting param
  * @param param Index of that param needs to get
  * @param value pointer to a space memory wheter used for storage that param 
  * @return Execution result 
  */
T_PsdkReturnCode PsdkFlir_GetParam(uint16_t param, int16_t *value)
{
    /*!< Check whether param has been read before then set state to fetch again */
    if(!s_camParams[param].seen) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    } 
    else {
        *value = s_camParams[param].value;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** 
  * @brief Function used for setting parameters 
  * @param param index of that param
  * @param value the value needs to set to memory
  * @return Execution Result 
  */
T_PsdkReturnCode PsdkFlir_SetParam(uint16_t param, const int16_t value)
{
    T_PsdkReturnCode gsdkStat = PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    
    /*!< Check whether param is consistent or exist */
    if((s_camParams[param].state == PARAM_STATE_CONSISTENT &&
        s_camParams[param].value == value) || s_camParams[param].state == PARAM_STATE_NONEEXISTANT) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
        
    DebugInfo("Set %d - %d", param, value);
    
    /*!< Set state to notify that need to set the new param */
    s_camParams[param].state = PARAM_STATE_ATTEMPTING_TO_SET;
    s_camParams[param].value = value;
    
    /*!< Call a callback function specified that platform used */
    gsdkStat = PsdkFlir_Write(param, value);
    
    /*!< Get time */
    PsdkOsal_GetTimeMs(&s_lastSetMs);
    
    return gsdkStat;
}

/** 
  * @brief Function handle param value 
  * @param arg Depending on the platform used.
  * @param none
  * @return None
  */
void PsdkFlir_HandleParamValue(const char* name, const uint16_t param, const int16_t value)
{
    /*!< Process param list and change the state */
//    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++) {
        /*!< Check param name is valid in the param list*/
        if(!strcmp(name, PsdkFlir_GetParamName(param))) {
            /*!< Switch to notify that just seen that param */
            s_camParams[param].seen = true;
            
            switch(s_camParams[param].state) {
                case PARAM_STATE_NONEEXISTANT:
                case PARAM_STATE_NOT_YET_READ: {
                    /*!< Get value to list */
                    s_camParams[param].value = value;
                    s_camParams[param].state = PARAM_STATE_CONSISTENT;
                    
                    DebugInfo("GOT [%s][%d]: %d", PsdkFlir_GetParamName(param), param, s_camParams[param].value);

                    break;
                }
                case PARAM_STATE_FETCH_AGAIN: {
                    /*!< Param has been set is compared with value just read */
                    if(s_camParams[param].value != value) {
                        s_camParams[param].state = PARAM_STATE_FETCH_AGAIN;
                    }
                    else {
                        s_camParams[param].value = value;
                        s_camParams[param].state = PARAM_STATE_CONSISTENT;
                    }
                    
                    DebugInfo("GOT_FETCH [%s][%d]: %d", PsdkFlir_GetParamName(param), param, s_camParams[param].value);

                    break;
                }
                case PARAM_STATE_CONSISTENT: {
                    /*!< Receive param */
                    s_camParams[param].value = value;
                    break;
                }
                case PARAM_STATE_ATTEMPTING_TO_SET: {
                    
                    /*!< The state of that param need to set*/
                    if(s_camParams[param].value == value) {
                        s_camParams[param].state = PARAM_STATE_CONSISTENT;
                    }
                    else {  /*!< Clear that param and waiting for response later*/
                        s_camParams[param].value = 0;
                        s_camParams[param].state = PARAM_STATE_CONSISTENT;
                    }
                    break;
                }
            }
//            break;  
//        }
    }
}


/** 
  * @brief Function used for update paramters. Check/set/get 
  * @param none
  * @return Exection Result 
  */
T_PsdkReturnCode PsdkFlir_UpdateParams(void)
{
    T_PsdkReturnCode gsdkStat = PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    
    uint32_t timeNowMs;
    int16_t  paramTemp;
    PsdkOsal_GetTimeMs(&timeNowMs);
    
       /*!< Retry initial param retrieval */
       for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++){
            /*!< Check whether param has been read before then set state to fetch again */
            if(s_camParams[i].state == PARAM_STATE_NOT_YET_READ || s_camParams[i].state == PARAM_STATE_FETCH_AGAIN) {
                
                /*!< Wating for sending a request read */
                if((timeNowMs - s_lastRequestMs) > PARAM_RETRY_PERIOD) {
                    s_lastRequestMs = timeNowMs;
                   
                    PsdkFlir_Read(i, &paramTemp);
                   
                    DebugInfo("Read[%d]: %d", i, paramTemp);

                    PsdkFlir_HandleParamValue(PsdkFlir_GetParamName(i), i, paramTemp);
                    
                    if(!s_camParams[i].seen) {
                        /*!< Increase time check */
                        s_camParams[i].fetchAttempts++;
                    }
                }
            }
        }
   
    /*!< Retry param set */
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++) {
        /*!< Check if param need to set  */
        if((s_camParams[i].state == PARAM_STATE_ATTEMPTING_TO_SET) && (timeNowMs - s_lastSetMs > PARAM_RETRY_PERIOD)) {
            /*!< Save param to platform */
            gsdkStat = PsdkFlir_Write(s_camParams[i].camIdx, s_camParams[i].value);
            
            s_lastSetMs = timeNowMs;
            
            /*!< Check param has been seen or not */ 
            if(!s_camParams[i].seen) {
                /*!< Increase time check */
                s_camParams[i].fetchAttempts++;
            }
            
            /*!< Switch to FETCH again to check */
            s_camParams[i].state = PARAM_STATE_FETCH_AGAIN;
            s_camParams[i].seen = false;
        }
    }
    
    /*!< Check for nonexistent parameter  */
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++) {
        if(!s_camParams[i].seen && s_camParams[i].fetchAttempts > PARAM_MAX_FETCH_ATTEMPTS) {
            s_camParams[i].state = PARAM_STATE_NONEEXISTANT;
            PsdkLogger_UserLogInfo("Param[%d] is not exist", i);
        }
    }
    
    return gsdkStat;
}

/** 
  * @brief Read param at startup
  * @param none
  * @param none
  * @return None
  */

T_PsdkReturnCode PsdkFlir_ReadParamStartup(void)
{
    int16_t paramTemp = 0;
    
    for(uint8_t i = 0; i < PARAM_ID_NUM_TRACKED; i++) {
        
        T_PsdkReturnCode psdkState = PsdkFlir_Read(i, &paramTemp);
        
        /*!< Read param from flash and override to param list */
        if(psdkState == PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
            s_camParams[i].value = paramTemp;
        }
        else {
            DebugWarning("WriteDef: [%d][%d]", i, s_camParams[i].value);
            
            /*!< Write as default */
            PsdkFlir_Write(i, s_camParams[i].value);
        }
    }
}

/*!<====================== MESSAGE_CONTROL ===================================*/

/**
 * @brief Function check FLIR is connected to the system
 * @details 
 * @note 
 */
static bool GremsyFLIR_isConnected(void )
{
    uint32_t tnow_ms = 0;
    
   /*!< Get time */
    PsdkOsal_GetTimeMs(&tnow_ms);

    /*!< Calculate the delta time */
    if(tnow_ms - s_pFLIRHandle->lastTimeConnection > PSDK_COMM_WAIT_RESPOND_TIMEOUT || !s_pFLIRHandle->isCameraConnected) {
        
        s_pFLIRHandle->isCameraConnected = false;
        
        PsdkLogger_UserLogWarn("Flir is not connected!");
        
        return false;
    } 
    
    return true;
}

/**
 * @brief
 * @details This structure type is used to
 * @note Camera R/S (Receive/Send)  
 */
T_PsdkReturnCode GremsyFLIR_SendHeartbeat(void)
{
    T_PsdkReturnCode psdkStat;
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_heartbeat_t heartbeat;
    
    /*!< Set default information*/
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    /*!< Set default*/
    heartbeat.type          = MAV_TYPE_GENERIC; 
    heartbeat.autopilot     = MAV_AUTOPILOT_INVALID;
    heartbeat.base_mode     = MAV_MODE_FLAG_MANUAL_INPUT_ENABLED;
    heartbeat.custom_mode   = 0; 
    heartbeat.system_status = MAV_STATE_ACTIVE;
    
    /*!< Message struct*/
    mavlink_message_t message_tx = {0};
    
    /*!< Encoder data to buffer*/
    mavlink_msg_heartbeat_encode_chan(  systemid, compid, chan, &message_tx, &heartbeat);
    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE];
    uint16_t len = 0;
    
    /*!< Clear buffer*/
    memset(msgbuf, 0x00, PSDK_COMM_WITH_CAMERA_BUFFER_SIZE);
    
    len = mavlink_msg_to_send_buffer(msgbuf, &message_tx);
    
    // Check length is valid
    if(len > 0) {
        // Send via MAVLINK_SEND_UART_BYTES 
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    }
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    psdkStat = Osal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief
 * @details This structure type is used to
 * @note R/S If PING is received, then will reply with a PING
 */
T_PsdkReturnCode GremsyFLIR_SendPing(void)
{
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_ping_t              ping = {0};

    /*< [us] Timestamp (UNIX Epoch time or time since system boot). 
    The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number.*/
    
    /*<  PING sequence*/
    /*<  0: request ping from all receiving systems, 
    if greater than 0: message is a ping response and number is the system id of the requesting system*/
    /*<  0: request ping from all receiving components, 
    if greater than 0: message is a ping response and number is the system id of the requesting system*/
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    ping.time_usec = xTaskGetTickCount() / 1000;
    ping.seq = s_pFLIRHandle->pingSeq++;
    ping.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    ping.target_component  = MAV_COMP_ID_CAMERA;

    mavlink_msg_ping_encode_chan(   systemid,
                                    compid,
                                    chan,
                                    &msg,
                                    &ping);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief System Master clock time 
 * @details 
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendSystemTime(void)
{
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_system_time_t       systemTime = {0};
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    /*< [us] Timestamp (UNIX epoch time).*/
    systemTime.time_unix_usec = xTaskGetTickCount()/1000;
    /*< [ms] Timestamp (time since system boot).*/
    systemTime.time_boot_ms = 0;
 
    mavlink_msg_system_time_encode_chan(systemid, compid, chan, &msg, &systemTime);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief The attitude in the aeronautical frame
 * @details 
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendAttitude(void)
{
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_attitude_t          attitude = {0};
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;

    /*< [ms] Timestamp (time since system boot).*/
    attitude.time_boot_ms = xTaskGetTickCount(); 
    /*< [rad] Roll angle (-pi..+pi)*/
    attitude.roll = 0; 
    /*< [rad] Pitch angle (-pi..+pi)*/
    attitude.pitch = 0; 
    /*< [rad] Yaw angle (-pi..+pi)*/
    attitude.yaw = 0; 
    /*< [rad/s] Roll angular speed*/
    attitude.rollspeed = 0; 
    /*< [rad/s] Pitch angular speed*/
    attitude.pitchspeed = 0;
    /*< [rad/s] Yaw angular speed*/
    attitude.yawspeed = 0; 
    
    mavlink_msg_attitude_encode_chan(systemid, compid, chan, &msg, &attitude);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief Filtered GPS position
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendGlobalPositionInit(void)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isReqDataStream) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_global_position_int_t          globalPosInit = {0};
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;

    /*!< Longitude, unit: deg. */
    /*!< Latitude, unit: deg. */
    /*!< Height above mean sea level, unit: m. */
    
    /*< [ms] Timestamp (time since system boot).*/
    PsdkOsal_GetTimeMs(&globalPosInit.time_boot_ms);
    /*< [degE7] Latitude, expressed*/
    globalPosInit.lat = geoTagInfo.rtkPosition.latitude * 1E7; 
    /*< [degE7] Longitude, expressed*/
    globalPosInit.lon = geoTagInfo.rtkPosition.longitude * 1E7; 
    /*< [mm] Altitude (MSL). Note that virtually all GPS modules provide both WGS84 and MSL.*/
    globalPosInit.alt = geoTagInfo.rtkPosition.hfsl * 1000;
    /*< [mm] Altitude above ground*/
    globalPosInit.relative_alt = 0; 
    /*< [cm/s] Ground X Speed (Latitude, positive north)*/
    globalPosInit.vx = geoTagInfo.rtkVelocity.x * 10000; /*!<  unit: cm/s.*/
    /*< [cm/s] Ground Y Speed (Longitude, positive east)*/
    globalPosInit.vy = geoTagInfo.rtkVelocity.y * 10000; /*!<  unit: cm/s.*/
    /*< [cm/s] Ground Z Speed (Altitude, positive down)*/
    globalPosInit.vz = geoTagInfo.rtkVelocity.z * 10000; /*!<  unit: cm/s.*/
    /*< [cdeg] Vehicle heading (yaw angle), 0.0..359.99 degrees. If unknown, set to: UINT16_MAX*/
    globalPosInit.hdg = geoTagInfo.rtkYaw;
    
    /*!< Encode to buffer */
    mavlink_msg_global_position_int_encode_chan(systemid, compid, chan, &msg, &globalPosInit);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    psdkStat = Osal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief Higher resolution filter GPS position
 * @details 
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendGlobalPositionInitCov(void)
{
     T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t                   msg = {0};
    uint16_t                            len = 0;
    mavlink_global_position_int_cov_t   globalPosInitCov = {0};
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;

     /*< [us] Timestamp (UNIX Epoch time or time since system boot). 
    The receiving end can infer timestamp format (since 1.1.1970 or since system boot) 
    by checking for the magnitude of the number.*/
    globalPosInitCov.time_usec = 0;
    /*< [degE7] Latitude*/
    globalPosInitCov.lat = 0; 
    /*< [degE7] Longitude*/
    globalPosInitCov.lon = 0; 
    /*< [mm] Altitude in meters above MSL*/
    globalPosInitCov.alt = 0; 
    /*< [mm] Altitude above ground*/
    globalPosInitCov.relative_alt = 0; 
    /*< [m/s] Ground X Speed (Latitude)*/
    globalPosInitCov.vx = 0; 
    /*< [m/s] Ground Y Speed (Longitude)*/
    globalPosInitCov.vy = 0; 
    /*< [m/s] Ground Z Speed (Altitude)*/
    globalPosInitCov.vz = 0; 
    /*<  Row-major representation of a 6x6 position and velocity 6x6 cross-covariance matrix 
    (states: lat, lon, alt, vx, vy, vz; first six entries are the first ROW, next six entries are the second row, etc.). 
    If unknown, assign NaN value to first element in the array.*/
//    globalPosInitCov.covariance[36] = {0};
    /*<  Class id of the estimator this estimate originated from.*/
    globalPosInitCov.estimator_type = 0; 
 
    /*!< Encode to buffer */
    mavlink_msg_global_position_int_cov_encode_chan(   systemid,
                                                        compid,
                                                        chan,
                                                        &msg,
                                                        &globalPosInitCov);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    psdkStat = Osal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief Raw GPS from sensor 
 * @details 
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendHilGPS(void)
{
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_hil_gps_t           hil_gps = {0};
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;

    /*< [us] Timestamp (UNIX Epoch time or time since system boot). 
    The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.*/
    hil_gps.time_usec = 0; 
    /*< [degE7] Latitude (WGS84)*/
    hil_gps.lat = 0; 
    /*< [degE7] Longitude (WGS84)*/
    hil_gps.lon = 0;
    /*< [mm] Altitude (MSL). Positive for up.*/
    hil_gps.alt = 0; 
    /*< [cm] GPS HDOP horizontal dilution of position. If unknown, set to: 65535*/
    hil_gps.eph = 0; 
    /*< [cm] GPS VDOP vertical dilution of position. If unknown, set to: 65535*/
    hil_gps.epv = 0;
    /*< [cm/s] GPS ground speed. If unknown, set to: 65535*/    
    hil_gps.vel = 0;
    /*< [cm/s] GPS velocity in north direction in earth-fixed NED frame*/    
    hil_gps.vn = 0;
    /*< [cm/s] GPS velocity in east direction in earth-fixed NED frame*/
    hil_gps.ve = 0; 
    /*< [cm/s] GPS velocity in down direction in earth-fixed NED frame*/
    hil_gps.vd = 0; 
    /*< [cdeg] Course over ground (NOT heading, but direction of movement), 0.0..359.99 degrees. If unknown, set to: 65535*/
    hil_gps.cog = 0; 
    /*<  0-1: no fix, 2: 2D fix, 3: 3D fix. Some applications will not use the value of this field unless it is at least two, so always correctly fill in the fix.*/
    hil_gps.fix_type = 0; 
    /*<  Number of satellites visible. If unknown, set to 255*/
    hil_gps.satellites_visible = 0; 
    /*<  GPS ID (zero indexed). Used for multiple GPS inputs*/
    hil_gps.id = 0; 
    /*< [cdeg] Yaw of vehicle relative to Earth's North, zero means not available, use 36000 for north*/
    hil_gps.yaw = 0;
    
    mavlink_msg_hil_gps_encode_chan(systemid, compid, chan, &msg, &hil_gps);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief Orientation of gimbal 
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendMountStatus(const T_PsdkAttitude3d *attitude)
{
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_mount_status_t      mountStatus = {0};
    
    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;

    /*< [cdeg] Pitch.*/
    mountStatus.pointing_a = attitude->pitch*100; 
    /*< [cdeg] Roll.*/
    mountStatus.pointing_b = attitude->roll*100; 
    /*< [cdeg] Yaw.*/
    mountStatus.pointing_c = attitude->yaw*100; 
    
    PsdkLogger_UserLogError("[%d][%d] ", mountStatus.pointing_a, mountStatus.pointing_c);
    
    /*<  System ID.*/
    mountStatus.target_system = 0; 
    /*<  Component ID.*/
    mountStatus.target_component = 0; 
        
    mavlink_msg_mount_status_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &mountStatus);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}


/**
 * @brief Function set layout IR/VIS/VIS_IR
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendDoControlVideo(uint8_t trans)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    /// control video
    command_long.command = MAV_CMD_DO_CONTROL_VIDEO;
    command_long.param1 = MAV_COMP_ID_CAMERA; 
    command_long.param2 = trans;                                    /// Transmission(output hdmi).    0: IR, 1: VIS, 2: VIS with IR(nho)
    command_long.param3 = 0;
    command_long.param4 = FLIR_VIDEO_RECORDING_IR_VIS;              /// Recording.                    0: IR, 1: VIS, 2: IR and VIS
    command_long.param5 = 0;
    command_long.param6 = 0;
    command_long.param7 = 0;
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
        
    } else {
        /*!< Get video transmission has been set previously */
//        FLIRCamera->videoTransmission = trans;
    }
    
    psdkStat = Osal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** @brief ham dung de cai dat thong so cho camera
    @param[in] scene chon sence loai moi truong hoat dong
    @param[in] palette chon mau hien thi cho camera IR
    @param[in] rotary chon do xoay cua hinh anh (0, 180)
    @param[in] Set MSX function 
    @param[in] Set MSX length 0 thr 100 inclusive
    @return none
*/
T_PsdkReturnCode GremsyFLIR_SendDoDigicamConfigure( uint8_t scene, uint8_t palette, uint8_t rotation, uint8_t MSX_enable, uint8_t MSX_length)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
        /// set param
    command_long.command = MAV_CMD_DO_DIGICAM_CONFIGURE;
    command_long.param1 = scene;        /// set scene       0: L, 1: D, 2: S, 3: O, 4: I, 5: M, 6: C1, 7: C2, 
    command_long.param2 = palette;      /// set IR Palette  0: White Hot, 1: Black Hot, 2: Red Hot, 3: Rainbow, 
                                        ///                 4: INVALID, 5: Lava, 6:  Arctic, 7: Globow, 8: Fusion
                                        ///                 9: InstAlert, 10: Grey Red, 11: Sepia, 12: INVALID, 13: INVALID(YELLOW & BLUE)
                                        ///                 14: Green Hot, 15: White Hot Iso, 16: Black Hot Iso, 17: Fusion Iso
                                        ///                 18: Rainbow Iso, 19: Globow Iso, 20: Ironbow White Hot Iso, 21: Ironbow Black Hot Iso,
                                        ///                 22: Sepia Iso, 23: Midrange White Hot Iso, 24: Midrange Black Hot Iso, 25: Ice Fire Iso,
                                        ///                 26: Rainbow HC Iso, 27: Red Hot Iso, 28: Green Hot Iso, 29: Arctic Black Hot Iso,
    command_long.param3 = 0;
    command_long.param4 = 0;
    command_long.param5 = rotation;     /// rotary image        0: Normal,  1: Inverted
    command_long.param6 = MSX_enable;            /// set MSX Function    0: Disable, 1: Enable
    command_long.param7 = MSX_length;            /// Main engine cut-off time before camretrigger in seconds/100 (0 means no cut-off). 0 to 100, inclusive
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
   /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
        /*!< Get Setting has been set previously */
        FLIRCamera->scene         = scene;
        FLIRCamera->palette       = palette;
        FLIRCamera->imageRotation = rotation;
        FLIRCamera->isMSXEnable   = MSX_enable;
        FLIRCamera->MSXLength     = MSX_length;
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
        
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/** @brief Control on-board camera 
    @param[in] Command FFC 
    @param[in] scene chon sence loai moi truong hoat dong
    @param[in] palette chon mau hien thi cho camera IR
    @param[in] rotary chon do xoay cua hinh anh (0, 180)
    @return none
*/
T_PsdkReturnCode GremsyFLIR_SendDoDigicamControl( float session,
                                                  float zoom_pos,
                                                  float zoom_step,
                                                  float focus_lock,
                                                  float shot_cmd,
                                                  float command_id,
                                                  float shot_id)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    
     /// set param
    command_long.command = MAV_CMD_DO_DIGICAM_CONTROL;
    command_long.param1 = session;     /// Session control e.g. show/hide lens
    command_long.param2 = zoom_pos;    /// Zoom's absolute position
    command_long.param3 = zoom_step;   /// Zooming step value to offset zoom from the current position        
    command_long.param4 = focus_lock;  /// Focus Locking, Unlocking or Re-locking        
    command_long.param5 = shot_cmd;    /// Shooting Command
    command_long.param6 = command_id;  /// Command Identity
    command_long.param7 = shot_id;     /// Empty
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
        
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendZoom(uint8_t zoomVIS, uint8_t zoomIR)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    if(zoomVIS > FLIR_ZOOM_VIS_MAX_LEVEL) {
        zoomVIS = FLIR_ZOOM_VIS_LEVEL_8;
    } 
    
    if(zoomIR > FLIR_ZOOM_IR_MAX_LEVEL) {
        zoomVIS = FLIR_ZOOM_IR_LEVEL_4;
    } 
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
     /// set param
    command_long.command = MAV_CMD_DO_DIGICAM_CONTROL;
    command_long.param1 = 0;
    command_long.param2 = zoomIR;                   /// Zoom IR tuyet doi   1, 2, 4
    command_long.param3 = zoomVIS;                 /// zoom VIS tuyet doi  1, 2, 4, 8
    command_long.param4 = 0; 
    command_long.param5 = 0;
    command_long.param6 = 0;
    command_long.param7 = 0;
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);

        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
        
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}



/**
  * @brief Start image capture sequence 
  *  Parameter 1 (Duration between two consecutive pictures in seconds). Inverval between captures 0 thr 60 inclusive
  *  Parameter 2 (for the specific command)
  *  Parameter 3 (for the specific command)
  *  Parameter 4 (for the specific command)
  *  Parameter 5 (for the specific command)
  *  Parameter 6 (for the specific command)
  *  Parameter 7 (for the specific command)
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendImageStartCapture(void)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
     /// set param
    command_long.command = MAV_CMD_IMAGE_START_CAPTURE;
    command_long.param1 = 0;          /// thoi gian giua hai lan chup lien tiep, khi se thoi gian hinh se duoc chup lien tiep. 0 - 60 second
    command_long.param2 = 0;          /// none
    command_long.param3 = FLIRCamera->fileFormat;          /// do phan giai cua hinh chup. 1: JPEG & TIFF, 2: FFF(FLIR File Format)
    command_long.param4 = 0;          /// none
    command_long.param5 = 0;          /// none
    command_long.param6 = 0;          /// none
    command_long.param7 = 0;          /// none
        
    command_long.confirmation      = 0; /*!< if it == 1 it will not run*/
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendImageStopCapture(void)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    command_long.command = MAV_CMD_IMAGE_STOP_CAPTURE;
    command_long.param1 = 0;
    command_long.param2 = 0;
    command_long.param3 = 0;
    command_long.param4 = 0;
    command_long.param5 = 0;
    command_long.param6 = 0;
    command_long.param7 = 0;
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}


/**
 * @brief
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendVideoStartCapture(void)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    command_long.command = MAV_CMD_VIDEO_START_CAPTURE;
    command_long.param1 = 0; /*!<  Camera ID. 0: All, 1: First, 2: Second.*/
    command_long.param2 = FLIRCamera->videoFileType; /*!< Frames/second. 1: H264, 2: TLFF. == 2 cannot record even using app*/ 
    command_long.param3 = 0;
    command_long.param4 = 0;
    command_long.param5 = 0;
    command_long.param6 = 0;
    command_long.param7 = 0;
    PsdkLogger_UserLogInfo("Set video file type :%d", FLIRCamera->videoFileType);
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendVideoStopCapture(void)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    command_long.command = MAV_CMD_VIDEO_STOP_CAPTURE;
    command_long.param1 = 0; /*!<  Camera ID. 0: All, 1: First, 2: Second.*/
    command_long.param2 = 0; /*!< Frames/second. 1: H264, 2: TLFF*/ 
    command_long.param3 = 0;
    command_long.param4 = 0;
    command_long.param5 = 0;
    command_long.param6 = 0;
    command_long.param7 = 0;
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief
 * @details This structure type is used to
 * @note Skycondition & humidity cannot use
 */
T_PsdkReturnCode GremsyFLIR_SendUser1(E_FlirTempUnit tempUnit, 
                                    E_FlirSpotMeter spotMeter, 
                                    uint8_t emissivity, 
                                    uint8_t skyCondition,
                                    int16_t airTemperature,
                                    uint8_t humidity,
                                    uint16_t subjectRange)
{
    T_PsdkReturnCode psdkStat;
    
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    /*!< Lock mutex to send data */
    psdkStat = Osal_MutexLock(s_pFLIRHandle->mutexSendGetAck);
    if( psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("lock mutexSendGetAck error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    command_long.command = MAV_CMD_USER_1;
    command_long.param1 = tempUnit;
    command_long.param2 = spotMeter;
    command_long.param3 = emissivity;
    command_long.param4 = skyCondition;
    command_long.param5 = airTemperature;
    command_long.param6 = humidity;
    command_long.param7 = subjectRange;
        
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    /*!< Get command ACK and Wait Feedback*/
    s_pFLIRHandle->waitCommandAck = command_long.command;
    
    /*!< Waiting semaphore from command ACK */
    psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, PSDK_COMM_WAIT_ACK_TIMEOUT);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        
        PsdkLogger_UserLogError("Wait semaphore flir error: 0x%08llX.", psdkStat);
    } else {
    }
    
    /*!< Clear command after processing done */
    s_pFLIRHandle->waitCommandAck = 0;
    
    /*!< Unlock Mutex */
    psdkStat = PsdkOsal_MutexUnlock(s_pFLIRHandle->mutexSendGetAck);
    if (psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("unlock mutex error: 0x%08llX.", psdkStat);
        return psdkStat;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GremsyFLIR_SendRequestInfo(uint16_t cmd )
{
    if(!s_pFLIRHandle->isCameraConnected) {
        return PSDK_ERROR_SYSTEM_MODULE_CODE_NOT_FOUND;
    }
    
    mavlink_message_t           msg = {0};
    uint16_t                    len = 0;
    mavlink_command_long_t      command_long = {0};

    uint8_t systemid    = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    uint8_t compid      = MAV_COMP_ID_SYSTEM_CONTROL;
    uint8_t chan        = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    
    command_long.command = cmd;
    command_long.param1 = 0;
    command_long.param2 = 0;
    command_long.param3 = 0;
    command_long.param4 = 0;
    command_long.param5 = 0;
    command_long.param6 = 0;
    command_long.param7 = 0;
    
    command_long.confirmation      = 0;
    command_long.target_component  = MAV_COMP_ID_CAMERA;
    command_long.target_system     = PSDK_COMM_SYSTEM_CONTROL_SYSTEM_ID;
    
    mavlink_msg_command_long_encode_chan(   systemid,
                                            compid,
                                            chan,
                                            &msg,
                                            &command_long);

    uint8_t msgbuf[PSDK_COMM_WITH_CAMERA_BUFFER_SIZE] = {0};
    len = mavlink_msg_to_send_buffer(msgbuf, &msg);

    if(len > 0) {
        _mavlink_send_uart(chan, (const char*) msgbuf, len);
    } 
    else {
        PsdkLogger_UserLogError("[%s][%d] - Invalid length", __FUNCTION__, __LINE__);
    
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/*
 * @brief Handle mavlink message
 * @param msg Pointer to frame to be read.
 * @param out mavlink message after parsing
 * @retval - None
 */
void PsdkCamera_HandleMessage(const mavlink_message_t* msg)
{
    // Check pointer is valid 
    if(msg == NULL) {
        return;
    }
    
//    PsdkLogger_UserLogInfo("Got ID :%d", msg->msgid);
    
    // Parse message id 
    switch(msg->msgid)
    {
        case MAVLINK_MSG_ID_HEARTBEAT:
        {
            mavlink_heartbeat_t packet;

            /* Call decode function */
            mavlink_msg_heartbeat_decode(msg, &packet);
            
            /*!< Set flir is connected */
            s_pFLIRHandle->isCameraConnected = true;
            
//            PsdkLogger_UserLogInfo("Got HB type :%d",packet.type);
            
            /*!< Get time*/
            Osal_GetTimeMs(&s_pFLIRHandle->lastTimeConnection);
            
            break;
        }
        case MAVLINK_MSG_ID_PING:
        {
            PsdkLogger_UserLogInfo("Got MAVLINK_MSG_ID_PING...!");
            break;
        }
        case MAVLINK_MSG_ID_SYSTEM_TIME:
        {
            PsdkLogger_UserLogInfo("Got MAVLINK_MSG_ID_SYSTEM_TIME...!");
            
            break;
        }
        /*!< See: "GCS_Mavlink.cpp"*/
        case MAVLINK_MSG_ID_REQUEST_DATA_STREAM:
        {
            mavlink_request_data_stream_t packet;
            
            mavlink_msg_request_data_stream_decode(msg, &packet);
           
            /*!< Check whether the request that for camera */
            /*!< Req rate = 2, stream_id = 6, start_stop = 1*/
            PsdkLogger_UserLogInfo("Req rate: %d , id: %d, start/stop: %d, comp: %d, %d", 
                    packet.req_message_rate, 
                    packet.req_stream_id, 
                    packet.start_stop, packet.target_component, packet.target_system);
                    
            s_pFLIRHandle->isReqDataStream = true;
            
            /*!< Get message Rate */
            s_pFLIRHandle->msgRate = packet.req_message_rate;
            
            break;
        }
        case MAVLINK_MSG_ID_COMMAND_ACK:
        {
            mavlink_command_ack_t packet;
            
            mavlink_msg_command_ack_decode(msg, &packet);
            
            PsdkLogger_UserLogInfo("Command ACK : %d result: %d, progress: %d", packet.command, packet.result, packet.progress);
            
            /*!< Check the ack is valid */
            if(s_pFLIRHandle->waitCommandAck == packet.command) {
                /*!< Release semaphore*/
                if(Osal_SemaphorePost(s_pFLIRHandle->semaphoreWaitAck) != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                    
                    PsdkLogger_UserLogError("Release Semaphore Failed");
                    
                    /*!< Reset command */
                    s_pFLIRHandle->waitCommandAck = 0;
                }
            }
            break;
        }
    }
}


/**
 * @brief Low level PSDK frame read function.
 * @param pReadData Pointer to frame to be read.
 * @param dataLen Frame length.
 * @retval -1: Read error.
 *          not -1: Counts of bytes read actually.
 */
static int PsdkCameraFlir_Read(uint8_t *pReadData, uint16_t dataLen)
{
    int res;

    res = UART_Read(PSDK_COMM_WITH_CAMERA_UART_NUM, pReadData, dataLen);
    return res;
}

/**
 * @brief Low level PSDK frame send function.
 * @param pSendData Pointer to frame to be sent.
 * @param dataLen Frame length.
 * @return PSDK function process state.
 */
static int PsdkCameraFlir_Write(const uint8_t *pSendData, uint16_t dataLen)
{

    int res = UART_Write(PSDK_COMM_WITH_CAMERA_UART_NUM, pSendData, dataLen);
    
//#if (SLOG_WIRIS == 0)
//    for(int i = 0; i < res;  i++)
//        PsdkLogger_UserLogWarn("[Write] - 0x%02X", pSendData[i]);
//#endif
    
    return res;
}

/**
  * @brief Function is used to register the function send 
  * @retval T_PsdkReturnCode
  */
T_PsdkReturnCode FlirCameraProto_RegSendDataFunc(SendCallbackFunc callbackFunc)
{
    if(callbackFunc == NULL){
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    s_pFLIRHandle->mavHandler.write   = callbackFunc;
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
  * @brief Function is used to register the function send 
  * @retval T_PsdkReturnCode
  */
T_PsdkReturnCode FlirCameraProto_RegRecvDataFunc(ReceiveCallbackFunc callbackFunc)
{
    if(callbackFunc == NULL){
        return PSDK_ERROR_SYSTEM_MODULE_CODE_INVALID_PARAMETER;
    }
    
    s_pFLIRHandle->mavHandler.read = callbackFunc;
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}


/** @brief Function parse FLIR data
  * @param none
  * @param none
  * @return None
  */
static T_PsdkReturnCode FlirProt_ProcessReceiveData(const uint8_t *pData, uint16_t realLen)
{
    // Scan the counts of bytes read actually.
    for (int i = 0; i < realLen; i++) {
        // Get data from buffer
        uint8_t c = pData[i];
        
        //===================== MAVLINK Recievie Function ==============================//            
        //// Try to get a new message
        if(mavlink_parse_char(PSDK_COMM_WITH_CAMERA_MAV_CHAN, c, &s_pFLIRHandle->msg, &s_pFLIRHandle->status)) {
            // Handle message here
            PsdkCamera_HandleMessage(&s_pFLIRHandle->msg);
        }
    }
    
    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

/**
 * @brief Function sets default all params for the camera. 
 * @details These params has got from the FLIR after reseting factory.
 * @note 
 */
static void FlirCamera_GetSettings(void) 
{
    /*!< Get param from FLASH*/
    PsdkFlir_GetParam(PARAM_ID_SENCE_MODE, (int16_t*)&FLIRCamera->scene);
    PsdkFlir_GetParam(PARAM_ID_COLOR_PALETTE, (int16_t*)&FLIRCamera->palette);
    
    PsdkFlir_GetParam(PARAM_ID_MSX_ENABLE,(int16_t*)& FLIRCamera->isMSXEnable);
    PsdkFlir_GetParam(PARAM_ID_MSX_LENGTH,(int16_t*)& FLIRCamera->MSXLength);
    
    PsdkFlir_GetParam(PARAM_ID_VIDEO_TRANSMISSION, (int16_t*)& FLIRCamera->videoTransmission);
    PsdkFlir_GetParam(PARAM_ID_VIDEO_FILE_TYPE, (int16_t*)& FLIRCamera->videoFileType);
    PsdkFlir_GetParam(PARAM_ID_FILE_FORMAT, (int16_t*)& FLIRCamera->fileFormat);
    
    PsdkFlir_GetParam(PARAM_ID_TEMP_UNIT, (int16_t*)& FLIRCamera->tempUnit);
    PsdkFlir_GetParam(PARAM_ID_TEMP_METER, (int16_t*)&FLIRCamera->spotMeter);
    PsdkFlir_GetParam(PARAM_ID_SUBJECT_EMISSIVITY, (int16_t*)&FLIRCamera->emissivity);
    PsdkFlir_GetParam(PARAM_ID_SKY_CONDITION, (int16_t*)&FLIRCamera->skyCondition);
    PsdkFlir_GetParam(PARAM_ID_AIR_TEMPERATURE, (int16_t*)&FLIRCamera->airTemperature);
    PsdkFlir_GetParam(PARAM_ID_HUMIDITY, (int16_t*)&FLIRCamera->humidity);
    PsdkFlir_GetParam(PARAM_ID_SUBJECT_RANGE, (int16_t*)&FLIRCamera->subjectRange);
}

/**
  * @brief GremsyFLIR_CameraInit
  * Initialization for interfacing with FLIR camera 
  */
T_PsdkReturnCode FLIRProto_CameraInit(void)
{
    /*!< Allocation memory */
    s_pFLIRHandle = PsdkOsal_Malloc(sizeof(T_FLIRHandle));

    /*!< Check pointer is valid */
    if(s_pFLIRHandle == NULL){
        PsdkLogger_UserLogError("Malloc Flir Handle Failed. !");
        return PSDK_ERROR_SYSTEM_MODULE_CODE_MEMORY_ALLOC_FAILED;
    }
    
    /*!< Clear buffer */
    memset(s_pFLIRHandle, 0x00, sizeof(T_FLIRHandle));
    
    /*!< Init UART*/
    UART_Init(PSDK_COMM_WITH_CAMERA_UART_NUM, PSDK_COMM_WITH_CAMERA_UART_BAUD);
    
   
    /*!< Init mavlink channel and assign function for sending message*/
    s_pFLIRHandle->mavHandler.version = 1;
    s_pFLIRHandle->mavHandler.chan    = PSDK_COMM_WITH_CAMERA_MAV_CHAN;
    s_pFLIRHandle->mavHandler.write   = PsdkCameraFlir_Write;
    
    /*!< Init mavlink function handler */
    gremsy_mavlink_init(&s_pFLIRHandle->mavHandler);
    
    /*!< Create mutext for send get ACK */
    if(Osal_MutexCreate(&s_pFLIRHandle->mutexSendGetAck) != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("mutexSendGetAck create error");
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    
    /*!< Using semaphore for synchronization the event when pasrsing the command ack received from camera*/
    if(Osal_SemaphoreCreate(&s_pFLIRHandle->semaphoreWaitAck, 1) != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("semaphorewaitAck create error");
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    
    /*!< Reset semaphore. This will be set when received a ack from the camera*/
    T_PsdkReturnCode psdkStat = Osal_SemaphoreTimedWait(s_pFLIRHandle->semaphoreWaitAck, 0);
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("Take semaphore failed 0x%08llX.", psdkStat);
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }

    return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS; 
}

/**
 * @brief Function process param
 * @details This function will be calked in the loop for check the parameters
 * @note 
 */
T_PsdkReturnCode FLIRProto_ParameterProcess(void)
{
    /*!< Check GMB state */
    switch(s_paramProcessState)
    {
        case FLIR_PROCESS_PARAM_STATE_IDLE:
        {
            /*!< Reset param*/
            PsdkFlir_ResetParams();
            
            /*!< Check param default with flash */
            PsdkFlir_ReadParamStartup();
            /*!< Request param again. */ 
            
            /* Switch to next state*/
            s_paramProcessState = FLIR_PROCESS_PARAM_STATE_INITIALIZING;
            break;
        }
        case FLIR_PROCESS_PARAM_STATE_INITIALIZING:
        {
            PsdkFlir_UpdateParams();
            
            /*!< Check whether param has been read all from the FLASH*/
            if(PsdkFlir_ReceivedAllParams() == PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                
                /*!< Switch to get settings */
                s_paramProcessState = FLIR_PROCESS_PARAM_STATE_GET_SETTINGS;
            }

            break;
        }
        case FLIR_PROCESS_PARAM_STATE_GET_SETTINGS:
        {
            /*!< Set default camera here*/
            FlirCamera_GetSettings();
            
            /*!< Switch to get settings */
            s_paramProcessState = FLIR_PROCESS_PARAM_STATE_PROCESS;
            
            break;
        }
        case FLIR_PROCESS_PARAM_STATE_PROCESS:
        {
            PsdkFlir_UpdateParams();   
            
            break;
        }
        
        case FLIR_PROCESS_PARAM_STATE_ERROR:
        {
            break;
        }
    }
}

/**
  * @brief GremsyGimbal_RecvTask
  * Task gimbal will interface with the gimbal by conveying gimbal data 
  * to app as well as gimbal command to gimbal devixe
  */
static void *CameraRecTask(void *parameter)
{
    uint32_t step = 0;
    
    while (1) {
        /*!< BaurdRare (Bd) = 115200  -- > 1Bd = 1 bit/s  --> 8.6us
            Uart Frame 12 bits. Time to read = 12*8.68 = 104.2 us --> frep = 9,6K
            Queue 1024 bytes. Delay 1ms is compatible.
         */
        
        int realLen = PsdkCameraFlir_Read(s_uartRecBuf, sizeof(s_uartRecBuf));
        
        if (realLen > 0) {
            //===================== WIRIS Recievie Function ==============================//
            //all callbacks process in this thread.
            FlirProt_ProcessReceiveData(s_uartRecBuf, realLen);
        }
        
        PsdkOsal_TaskSleepMs(1000 / FLIR_CAMERA_TASK_FREQ);
        step++;
        
        uint32_t currentTimeMs = 0;
        if(PsdkOsal_GetTimeMs(&currentTimeMs) != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
            DebugError("Get Time Ms ");
        }
        
        /*!< Check the command connection */
        if(currentTimeMs - s_pFLIRHandle->lastTimeConnection > PSDK_COMM_WAIT_RESPOND_TIMEOUT) {
            /*!< FLIR lost connection 
              - Clear flag 
              - Switch to state lost connection 
            */
            if(s_pFLIRHandle->isCameraConnected) {
                s_pFLIRHandle->isCameraConnected = false;
            
                /*!< Check if the camera already is running then lost connection  */
                s_cameraRunningState = CAMERA_RUNNING_STATE_CHECK_CONNECTION;
            }
        }

        /*!< Process params */
        FLIRProto_ParameterProcess();
        
        /*!< Camera now is ready */
        if(s_cameraRunningState == CAMERA_RUNNING_STATE_PROCESS_EVENT) {
            /*!< Send heartbeat periodically 1Hz */
            if (USER_UTIL_IS_WORK_TURN(step, 1, FLIR_CAMERA_TASK_FREQ)) {
                GsdkFLIR_CameraSetEvent(CAM_EVENT_SEND_HANDSHAKE);
            }
            
            /*!< Send GPS periodically 2Hz */
            if (USER_UTIL_IS_WORK_TURN(step, 2, FLIR_CAMERA_TASK_FREQ)) {
                
                PsdkLogger_UserLogWarn("paramstate: %d, runningState: %d", s_paramProcessState, s_cameraRunningState);
                
                GsdkFLIR_CameraSetEvent(CAM_EVENT_SEND_INFO);
            }
        }
    }
}

/**
  * @brief GremsyGimbal_RecvTask
  * Task gimbal will interface with the gimbal by conveying gimbal data 
  * to app as well as gimbal command to gimbal devixe
  */
static void *ProcessCommandTask(void *parameter)
{
    T_PsdkReturnCode psdkStat = PSDK_ERROR_SYSTEM_MODULE_CODE_SYSTEM_ERROR;
    
    static uint32_t     step = 0;    
    uint8_t             countMsg = 0;

    /*!< Attempt to create the event group*/
    s_eventCamera = xEventGroupCreate();
    
    /*!< Event bit to check */
    EventBits_t event;
    
    while(1) {
        
        PsdkOsal_TaskSleepMs(1000 / FLIR_CAMERA_TASK_FREQ);
        step++;
        
        /*!< Check camera running state */
        if(s_cameraRunningState == CAMERA_RUNNING_STATE_IDLE) {
            
            s_cameraRunningState = CAMERA_RUNNING_STATE_CHECK_CONNECTION;
        }
        else if(s_cameraRunningState == CAMERA_RUNNING_STATE_CHECK_CONNECTION) {

            /*!< Send heartbeat periodically 1Hz */
            if (USER_UTIL_IS_WORK_TURN(step, 1, FLIR_CAMERA_TASK_FREQ)) {
                psdkStat = GremsyFLIR_SendHeartbeat();
                if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                    PsdkLogger_UserLogError(".......Send HB FAILED ! 0x%08llX.", psdkStat);
                }  
            }
            
            /*!< Send heartbeat periodically 2Hz */
            if (USER_UTIL_IS_WORK_TURN(step, 2, FLIR_CAMERA_TASK_FREQ)) {
                psdkStat = GremsyFLIR_SendGlobalPositionInit();
                if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                    PsdkLogger_UserLogError(".......Send GPS FAILED ! 0x%08llX.", psdkStat);
                }  
            }
            
            /*!< Camera is connected */
            if(s_pFLIRHandle->isCameraConnected) {
                
                /*!< Has been got request data stream */
                if(s_pFLIRHandle->isReqDataStream) {
                    s_pFLIRHandle->isReqDataStream = false;
                    
                    s_cameraRunningState = CAMERA_RUNNING_STATE_DEFAULT_SETTING;
                }
            }
        }
        else if(s_cameraRunningState == CAMERA_RUNNING_STATE_DEFAULT_SETTING) {

            /*!< Check whether som is reset ted */
            if(!s_pFLIRHandle->isSOMReseted) {
                 s_pFLIRHandle->isSOMReseted = true;
                
                /*!< Reset SOM */
                PsdkSom_WriteHardwareResetPin(SOM_HW_RESET_MANAGEMENT_PIN_STATE_RESET);
                PsdkOsal_TaskSleepMs(50);
                PsdkSom_WriteHardwareResetPin(SOM_HW_RESET_MANAGEMENT_PIN_STATE_SET);
                PsdkOsal_TaskSleepMs(50);
                
                PsdkLogger_UserLogWarn("Reset SOM !!!!!");
            }
            
            /*!< Check params whether read*/
            if(s_paramProcessState == FLIR_PROCESS_PARAM_STATE_PROCESS) {
                /*!< Switch to setting camera */
                s_cameraRunningState = CAMERA_RUNNING_QUERY_CAMERA_SETTING;
            }
        }
        else if(s_cameraRunningState == CAMERA_RUNNING_QUERY_CAMERA_SETTING) {
            
            if(countMsg == 0) {
                /*!< Set flir default parameter */
                GremsyFLIR_SendDoDigicamConfigure(FLIRCamera->scene, 
                                                FLIRCamera->palette, 
                                                FLIRCamera->imageRotation, 
                                                FLIRCamera->isMSXEnable, 
                                                FLIRCamera->MSXLength);
                countMsg++;
            }
            else if(countMsg == 1) {
                
                GremsyFLIR_SendDoControlVideo(FLIRCamera->videoTransmission);
                countMsg++;
            }
            else if(countMsg == 2) {
                GremsyFLIR_SendUser1(FLIRCamera->tempUnit, 
                                FLIRCamera->spotMeter, 
                                FLIRCamera->emissivity, 
                                FLIRCamera->skyCondition, 
                                FLIRCamera->airTemperature, 
                                FLIRCamera->humidity, 
                                FLIRCamera->subjectRange);
                
                countMsg++;
            }
            else if(countMsg == 3) {
                /*!< Reset zoom value */
                GremsyFLIR_SendZoom(FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
                countMsg++;
            }
            else if(countMsg == 4) {                
                FLIRCamera->zoomIRLevel       = FLIR_ZOOM_IR_LEVEL_1;
                FLIRCamera->zoomVISLevel      = FLIR_ZOOM_VIS_LEVEL_1;
                GremsyFLIR_SendZoom(FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
                
                countMsg++;
            }
             else if(countMsg == 5) {
                countMsg = 0;
             
                /*!< Switch to process commands*/
                s_cameraRunningState = CAMERA_RUNNING_STATE_PROCESS_EVENT;
             }
        }
        else if(s_cameraRunningState == CAMERA_RUNNING_STATE_PROCESS_EVENT) {
        /*!<----------------------Process Event group --------------------------------
        Block to for any event to be set within the event group. 
        Clear the bit before existing block to wait for one or more bits to be set within a previously created event group. */
            
            event = xEventGroupWaitBits(s_eventCamera, CAM_EVENT_ALLS, pdTRUE, pdFALSE, portMAX_DELAY);

            if(event & CAM_EVENT_SEND_HANDSHAKE)
            {
                psdkStat = GremsyFLIR_SendHeartbeat();
                if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                    PsdkLogger_UserLogError(".......Send HB FAILED ! 0x%08llX.", psdkStat);
                }  
            }
                
            if(event & CAM_EVENT_SEND_INFO) {
                 psdkStat = GremsyFLIR_SendGlobalPositionInit();
                if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                    PsdkLogger_UserLogError(".......Send GPS FAILED ! 0x%08llX.", psdkStat);
                }  
            }
            
            /*!< Event capture photo*/
            if(event & CAM_EVENT_SET_START_SHOOT_PHOTO) {
                if(GremsyFLIR_SendImageStartCapture() != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                    PsdkLogger_UserLogError("Shoot photo FAILED!");
                }
                else {
                    PsdkFlir_SetParam(PARAM_ID_FILE_FORMAT, FLIRCamera->fileFormat);
                    PsdkLogger_UserLogInfo("Shoot photo COMPLETE!");
                }
            }
            
            /*!< Set record video */
            if(event & CAM_EVENT_SET_START_RECORD) {
                if(!FLIRCamera->isRecording) {
                    /*!< Check where the camera is recording */
                    if(GremsyFLIR_SendVideoStartCapture() != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                        
                        /*!< Recording failed */
                        FLIRCamera->isRecording = false;
                    } 
                    else {
                        DebugInfo("Camera is recording !");
                        
                        FLIRCamera->isRecording = true;
                        PsdkFlir_SetParam(PARAM_ID_VIDEO_FILE_TYPE, FLIRCamera->videoFileType);
                    }
                }
            }
            
            if(event & CAM_EVENT_SET_STOP_RECORD) {
                
                /*!< Check camera is recording*/
                if(FLIRCamera->isRecording) {
                    if(GremsyFLIR_SendVideoStopCapture() != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
                        FLIRCamera->isRecording = false;
                    } 
                }
            }
            
            /*!< Event set camera zoom*/
            if(event & CAM_EVENT_SET_ZOOM_IN) {
                PsdkLogger_UserLogInfo("Zoom VIS = %d IR = %d", FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
                GremsyFLIR_SendZoom(FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
            }
            
            if(event & CAM_EVENT_SET_ZOOM_OUT) {
                PsdkLogger_UserLogInfo("Zoom VIS = %d IR = %d", FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
                GremsyFLIR_SendZoom(FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
            }
            
            /*!< Reset Zoom value */
            if(event & CAM_EVENT_RESET_DIGITAL_ZOOM_FACTOR) {
                FLIRCamera->zoomIRLevel       = FLIR_ZOOM_IR_LEVEL_1;
                FLIRCamera->zoomVISLevel      = FLIR_ZOOM_VIS_LEVEL_1;
                GremsyFLIR_SendZoom(FLIRCamera->zoomVISLevel, FLIRCamera->zoomIRLevel);
            }
            
            /*!< Event set camera video transmision to HDMI */
            if(event & CAM_EVENT_SET_LAYOUT) {
                PsdkLogger_UserLogInfo("Set layout %d", FLIRCamera->videoTransmission);
                GremsyFLIR_SendDoControlVideo(FLIRCamera->videoTransmission);
                
                PsdkFlir_SetParam(PARAM_ID_VIDEO_TRANSMISSION, FLIRCamera->videoTransmission);
            }
             
            if(event & CAM_EVENT_SET_DIGICAM_CONTROL) {
                GremsyFLIR_SendDoDigicamControl(1, FLIRCamera->zoomIRLevel, FLIRCamera->zoomVISLevel,1,0,0,0);
            }
            
            /*!< Set event config flir */
            if(event & CAM_EVENT_SET_DIGICAM_CONFIG) {
                PsdkLogger_UserLogInfo("Set config %d %d %d %d %d ",
                                                    FLIRCamera->scene, 
                                                    FLIRCamera->palette, 
                                                    FLIRCamera->imageRotation,
                                                    FLIRCamera->isMSXEnable,
                                                    FLIRCamera->MSXLength);
                
                GremsyFLIR_SendDoDigicamConfigure(FLIRCamera->scene, 
                                                    FLIRCamera->palette, 
                                                    FLIRCamera->imageRotation,
                                                    FLIRCamera->isMSXEnable,
                                                    FLIRCamera->MSXLength);
                
                PsdkFlir_SetParam(PARAM_ID_SENCE_MODE, FLIRCamera->scene);
                PsdkFlir_SetParam(PARAM_ID_COLOR_PALETTE, FLIRCamera->palette);
                
                PsdkFlir_SetParam(PARAM_ID_MSX_ENABLE, FLIRCamera->isMSXEnable);
                PsdkFlir_SetParam(PARAM_ID_MSX_LENGTH, FLIRCamera->MSXLength);
            }
            
            if(event & CAM_EVENT_SET_PARMETERS) {
                PsdkLogger_UserLogInfo("Set params %d %d %d %d %d %d %d ", FLIRCamera->tempUnit, 
                                                                        FLIRCamera->spotMeter, 
                                                                        FLIRCamera->emissivity, 
                                                                        FLIRCamera->skyCondition, 
                                                                        FLIRCamera->airTemperature, 
                                                                        FLIRCamera->humidity, 
                                                                        FLIRCamera->subjectRange);
                
                GremsyFLIR_SendUser1(FLIRCamera->tempUnit, 
                                    FLIRCamera->spotMeter, 
                                    FLIRCamera->emissivity, 
                                    FLIRCamera->skyCondition, 
                                    FLIRCamera->airTemperature, 
                                    FLIRCamera->humidity, 
                                    FLIRCamera->subjectRange);
                
                PsdkFlir_SetParam(PARAM_ID_TEMP_UNIT, FLIRCamera->tempUnit);
                PsdkFlir_SetParam(PARAM_ID_TEMP_METER, FLIRCamera->spotMeter);
                PsdkFlir_SetParam(PARAM_ID_SUBJECT_EMISSIVITY, FLIRCamera->emissivity);
                PsdkFlir_SetParam(PARAM_ID_SKY_CONDITION, FLIRCamera->skyCondition);
                PsdkFlir_SetParam(PARAM_ID_AIR_TEMPERATURE, FLIRCamera->airTemperature);
                PsdkFlir_SetParam(PARAM_ID_HUMIDITY, FLIRCamera->humidity);
                PsdkFlir_SetParam(PARAM_ID_SUBJECT_RANGE, FLIRCamera->subjectRange);
            }
        }
        else if(s_cameraRunningState == CAMERA_RUNNING_STATE_ERROR) {
            
        }
    }
}

/*!<====================== PUBLIC_FUNCTIONS =================================== */

/** @addtogroup 
  * @{ PUBLIC_FUNCTIONS
  */

/**
 * @brief 
 * @details This structure type is used to
 * @note 
 */
T_PsdkReturnCode GsdkFLIR_CameraInit(void) 
{
    T_PsdkReturnCode psdkStat = PSDK_ERROR_SYSTEM_MODULE_CODE_SYSTEM_ERROR;
    
     /* Unlock the Flash to enable the flash control register access *************/
    if(HAL_FLASH_Unlock() != HAL_OK) {
        PsdkLogger_UserLogError("FLASH unlock failed!");
    }

    /* Clear pending flags (if any) */
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR |
                           FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);

    /*!< EEPROM Init*/
    if(EE_Init() != EE_OK) {
        PsdkLogger_UserLogError("EEPROM Inititialized failed!");
    }
    
    /*!< Reset param*/
    PsdkFlir_ResetParams();
    
    /*!< Check param default with flash */
    PsdkFlir_ReadParamStartup();
    
    /*!<------------------ FLIR PROTOCOL INIT --------------------------------*/
    psdkStat = FLIRProto_CameraInit();
    if(psdkStat != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        PsdkLogger_UserLogError("FLIR Camera proto init Failed");
        return psdkStat;
    }
    
    /*!< Create the camera wiris receive data thread */
    if(PsdkOsal_TaskCreate(&s_recvThread, CameraRecTask, "flir_recv_task", 
        FLIR_CAMERA_TASK_STACK_SIZE, NULL) != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS){
        PsdkLogger_UserLogError("user camera task create error");
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    
    /*!< Create the camera wiris command process thread */
    if(PsdkOsal_TaskCreate(&s_processCmdThread, ProcessCommandTask, "flir_cmd_task", 
        FLIR_CAMERA_TASK_STACK_SIZE, NULL) != PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS){
        PsdkLogger_UserLogError("user camera task create error");
        return PSDK_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }

    return psdkStat;
}


T_PsdkReturnCode GsdkFLIR_CameraDeInit(void)
{
    
}

T_PsdkReturnCode GsdkFLIR_CameraSetEvent(const uint32_t uxBitsToSet)
{
     // Was the event group created successfully?
    if( s_eventCamera != NULL && s_cameraRunningState == CAMERA_RUNNING_STATE_PROCESS_EVENT) {
         /*!< Set event to check camera is recording*/
        xEventGroupSetBits(s_eventCamera, uxBitsToSet);
        
        return PSDK_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
    }

    return PSDK_ERROR_SYSTEM_MODULE_CODE_SYSTEM_ERROR;
}

/**
  * @} // PUBLIC_FUNCTIONS
  */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
